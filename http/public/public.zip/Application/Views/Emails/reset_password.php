Please click on the link bellow to reset your password: 
<?php echo $link ?>