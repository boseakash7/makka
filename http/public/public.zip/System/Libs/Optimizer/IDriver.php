<?php

namespace System\Libs\Optimizer;

interface IDriver
{
    public function get();
}